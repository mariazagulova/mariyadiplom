/*
 *  stdp_nora_connection.cpp
 *
 *
 */

#include "network.h"
#include "dictdatum.h"
#include "connector_model.h"
#include "common_synapse_properties.h"
#include "stdp_nora_connection.h"
#include "event.h"
#include "nestmodule.h"

namespace nest
{
//
// Implementation of class STDPNoraCommonProperties.
//

STDPNoraCommonProperties::STDPNoraCommonProperties()
  : CommonSynapseProperties()
  , vt_( 0 )
  , A_plus_( 1.0 )
  , A_minus_( 1.5 )
  , tau_plus_( 20.0 )
  , tau_c_( 1000.0 )
  , tau_n_( 200.0 )
  , b_( 0.0 )
  , Wmin_( 0.0 )
  , Wmax_( 200.0 )
{
}

void
STDPNoraCommonProperties::get_status( DictionaryDatum& d ) const
{
  CommonSynapseProperties::get_status( d );

  if ( vt_ != 0 )
    def< long_t >( d, "vt", vt_->get_gid() );
  else
    def< long_t >( d, "vt", -1 );

  def< double_t >( d, "A_plus", A_plus_ );
  def< double_t >( d, "A_minus", A_minus_ );
  def< double_t >( d, "tau_plus", tau_plus_ );
  def< double_t >( d, "tau_c", tau_c_ );
  def< double_t >( d, "tau_n", tau_n_ );
  def< double_t >( d, "b", b_ );
  def< double_t >( d, "Wmin", Wmin_ );
  def< double_t >( d, "Wmax", Wmax_ );
}

void
STDPNoraCommonProperties::set_status( const DictionaryDatum& d, ConnectorModel& cm )
{
  CommonSynapseProperties::set_status( d, cm );

  long_t vtgid;
  if ( updateValue< long_t >( d, "vt", vtgid ) )
  {
    vt_ = dynamic_cast< volume_transmitter* >( NestModule::get_network().get_node( vtgid ) );

    if ( vt_ == 0 )
      throw BadProperty( "Noradrenaline source must be volume transmitter" );
  }

  updateValue< double_t >( d, "A_plus", A_plus_ );
  updateValue< double_t >( d, "A_minus", A_minus_ );
  updateValue< double_t >( d, "tau_plus", tau_plus_ );
  updateValue< double_t >( d, "tau_c", tau_c_ );
  updateValue< double_t >( d, "tau_n", tau_n_ );
  updateValue< double_t >( d, "b", b_ );
  updateValue< double_t >( d, "Wmin", Wmin_ );
  updateValue< double_t >( d, "Wmax", Wmax_ );
}

Node*
STDPNoraCommonProperties::get_node()
{
  if ( vt_ == 0 )
    throw BadProperty( "No volume transmitter has been assigned to the noradrenaline synapse." );
  else
    return vt_;
}

} // of namespace nest
