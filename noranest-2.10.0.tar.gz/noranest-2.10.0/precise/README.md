# `precise` folder

The synapse, device, and neuron models for precise timing simulations with NEST.
