
The example scripts presented in the "NEST by Example" chapter in
Le Novere (2012) are now maintained in directory

	doc/nest_by_example/scripts
	
Hans E Plesser, 2014-12-12
