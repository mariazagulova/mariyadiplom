# `sli` folder

Implementation files of the integrated simulation language interpreter.
